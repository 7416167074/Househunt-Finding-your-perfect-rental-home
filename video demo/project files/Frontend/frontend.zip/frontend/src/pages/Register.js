
import { useState } from "react";
import axios from "axios";

function Register() {
  const [user, setUser] = useState({ name:"", email:"", password:"", role:"renter" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/users/register", user);
    alert("Registered Successfully");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Name" onChange={e=>setUser({...user,name:e.target.value})}/>
      <input placeholder="Email" onChange={e=>setUser({...user,email:e.target.value})}/>
      <input type="password" placeholder="Password" onChange={e=>setUser({...user,password:e.target.value})}/>
      <select onChange={e=>setUser({...user,role:e.target.value})}>
        <option value="renter">Renter</option>
        <option value="owner">Owner</option>
      </select>
      <button>Register</button>
    </form>
  );
}

export default Register;
