
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Properties from "./pages/Properties";
import AddProperty from "./pages/AddProperty";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Properties />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/add-property" element={<AddProperty />} />
      </Routes>
    </Router>
  );
}

export default App;
